package com.frank.ttt;

public class ttt {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Integer[][] winCondition = {
					{0,1,2},
					{3,4,5},
					{6,7,8},
					{0,3,6},
					{1,4,7},
					{2,5,8},
					{0,4,8},
					{2,4,6}
				};
				
		String[] layerOut = {
				":o", ":e", ":e",
				":e", ":o", ":e",
				":e", ":e", ":o"
				};

		for(int i=0; i<winCondition.length; i++) {
			if(layerOut[winCondition[i][0]].equals(":e")) {
				continue;
			}
			if(layerOut[winCondition[i][0]].equals(layerOut[winCondition[i][1]]) 
					&& layerOut[winCondition[i][0]].equals(layerOut[winCondition[i][2]])) {
				System.out.println(layerOut[winCondition[i][0]] );
				return;
			}
		}
		
		System.out.println(":n");
		
	}

}
